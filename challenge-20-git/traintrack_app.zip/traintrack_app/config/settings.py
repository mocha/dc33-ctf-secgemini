
# General Application Settings for TrainTrack
import os
from datetime import timedelta

class AppConfig:
    # Environment and Debugging
    DEBUG = os.environ.get('FLASK_ENV', 'development') == 'development'
    TESTING = False
    ENV = os.environ.get('FLASK_ENV', 'development')

    # Paths (relative to the base directory of the project)
    BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    TEMPLATE_FOLDER = os.path.join(BASE_DIR, 'src', 'client', 'templates') # Corrected template path
    STATIC_FOLDER = os.path.join(BASE_DIR, 'src', 'client', 'static')
    LOGS_DIR = os.path.join(BASE_DIR, 'logs')
    DATA_DIR = os.path.join(BASE_DIR, 'data')

    # Database Configuration
    DATABASE_URL = os.environ.get('DATABASE_URL', f'sqlite:///{DATA_DIR}/traintrack.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False # For Flask-SQLAlchemy integration

    # API Endpoints
    API_EXTERNAL_TRAINS_ENDPOINT = os.environ.get('EXTERNAL_TRAINS_API', 'https://api.external-train-provider.com/v2/data')

    # Security Settings
    SECRET_KEY = os.environ.get('SECRET_KEY', 'a_long_and_complex_secret_key_for_flask_sessions_and_more_here_12345')
    SECURITY_PASSWORD_SALT = os.environ.get('SECURITY_PASSWORD_SALT', 'another_random_string_for_password_hashing_98765')
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'default_jwt_secret_for_dev')
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)

    # Logging Configuration
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOGGING_CONFIG_PATH = os.path.join(BASE_DIR, 'config', 'logging.ini')

    # Cache Configuration
    CACHE_TYPE = os.environ.get('CACHE_TYPE', 'simple') # 'redis' or 'memcached' in production
    CACHE_DEFAULT_TIMEOUT = int(os.environ.get('CACHE_DEFAULT_TIMEOUT', 300)) # seconds

    # Other Settings
    APP_NAME = "TrainTrack"
    VERSION = "1.1.0"
    ADMIN_EMAIL = "admin@traintrack.com"
