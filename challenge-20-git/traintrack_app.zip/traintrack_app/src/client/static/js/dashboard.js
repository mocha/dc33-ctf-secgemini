
document.addEventListener('DOMContentLoaded', () => {
    console.log('TrainTrack dashboard script loaded.');

    const viewMapBtn = document.getElementById('view-map-btn');
    if (viewMapBtn) {
        viewMapBtn.addEventListener('click', () => {
            // In a real app, this would route to a map page or show a modal
            alert('Live Map feature is under development! Stay tuned.');
        });
    }

    // Function to fetch and display train data (mock or real API)
    async function fetchTrainData() {
        try {
            const response = await fetch('/api/v1/trains');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const trains = await response.json();
            
            const container = document.getElementById('train-list-container');
            if (container) {
                container.innerHTML = '<h3>Current Train Status</h3>';
                if (trains && trains.length > 0) {
                    const ul = document.createElement('ul');
                    trains.forEach(train => {
                        const li = document.createElement('li');
                        li.className = 'train-item';
                        li.textContent = `Train ${train.id}: ${train.status} - ${train.currentLocation} (Last updated: ${AppUtilities.formatDate(train.last_updated)})`;
                        ul.appendChild(li);
                    });
                    container.appendChild(ul);
                } else {
                    container.innerHTML += '<p>No live train data available at the moment.</p>';
                }
            }
        } catch (error) {
            console.error('Failed to fetch train data:', error);
            const container = document.getElementById('train-list-container');
            if (container) {
                container.innerHTML = '<p style="color: red;">Error loading train data. Please try again later.</p>';
            }
        }
    }

    // Initial data fetching
    fetchTrainData();
    // Refresh data every 5 minutes
    setInterval(fetchTrainData, 5 * 60 * 1000);
});
