
-- Migration: 001_initial_schema.sql
-- Description: Create initial tables for trains and users.

CREATE TABLE IF NOT EXISTS trains (
    id VARCHAR(50) PRIMARY KEY,
    route_name VARCHAR(100) NOT NULL,
    current_status VARCHAR(50) NOT NULL,
    current_location VARCHAR(100),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(128) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for common lookup fields
CREATE INDEX idx_trains_status ON trains (current_status);
CREATE INDEX idx_users_email ON users (email);

-- Insert some initial dummy data for application testing
INSERT INTO trains (id, route_name, current_status, current_location) VALUES
('TRN001', 'North Express', 'On Time', 'Central Station'),
('TRN002', 'South Local', 'Delayed', 'Parkside Stop'),
('TRN003', 'East Cargo', 'Approaching', 'Industrial Yard');

INSERT INTO users (username, email, password_hash) VALUES
('admin', 'admin@traintrack.com', 'pbkdf2:sha256:150000$salt$hash_of_password_for_admin'),
('viewer', 'viewer@traintrack.com', 'pbkdf2:sha256:150000$salt$hash_of_password_for_viewer');
