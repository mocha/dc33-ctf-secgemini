
import datetime

# This file defines conceptual ORM models for TrainTrack application.
# In a real system, these would be mapped to database tables using SQLAlchemy.

class Train:
    """Represents a train in the system with its current status and location."""
    def __init__(self, id, route, status, location):
        self.id = id
        self.route = route
        self.status = status
        self.currentLocation = location
        self.last_updated = datetime.datetime.utcnow()

    def __repr__(self):
        return f"<Train {self.id} - {self.status} at {self.currentLocation}>"

    def to_dict(self):
        return {
            "id": self.id,
            "route": self.route,
            "status": self.status,
            "currentLocation": self.currentLocation,
            "last_updated": self.last_updated.isoformat()
        }

class User:
    """Represents a user of the TrainTrack application with basic authentication info."""
    def __init__(self, id, username, email, password_hash):
        self.id = id
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.created_at = datetime.datetime.utcnow()

    def __repr__(self):
        return f"<User {self.username} ({self.email})>"

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "created_at": self.created_at.isoformat()
        }

# Data access layer placeholder (in a real app, this would be a service or repository)
class TrainRepository:
    def get_all_trains(self):
        # Mock database query
        return [
            Train("TRN001", "North Express", "On Time", "Central Station"),
            Train("TRN002", "South Local", "Delayed", "Parkside Stop"),
            Train("TRN003", "East Cargo", "Approaching", "Industrial Yard")
        ]
    
    def get_train_by_id(self, train_id):
        # Mock lookup
        for train in self.get_all_trains():
            if train.id == train_id:
                return train
        return None
