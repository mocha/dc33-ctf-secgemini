
from flask import Flask, render_template, jsonify, request
from config.settings import AppConfig # Import the config class
from src.server.db.models import Train, User # Assuming these exist from models.py
import datetime
import os # Added for path operations

# Initialize app with config
app = Flask(__name__,
            template_folder=AppConfig.TEMPLATE_FOLDER,
            static_folder=AppConfig.STATIC_FOLDER)

# Set Flask config from AppConfig object
app.config.from_object(AppConfig)

# --- Routes ---

@app.route('/')
@app.route('/dashboard')
def index():
    # Renders the main dashboard page
    return render_template('index.html')

@app.route('/api/v1/trains', methods=['GET'])
def get_trains():
    # Placeholder for fetching real train data
    # In a real app, this would query a database or an external API
    # Example: fetch from AppConfig.API_EXTERNAL_TRAINS_ENDPOINT
    mock_train_data = [
        {"id": "TRN001", "status": "On Time", "currentLocation": "Station A", "route": "Express Line", "last_updated": datetime.datetime.now().isoformat()},
        {"id": "TRN002", "status": "Delayed (10min)", "currentLocation": "Station B", "route": "Local Line", "last_updated": datetime.datetime.now().isoformat()},
        {"id": "TRN003", "status": "Approaching", "currentLocation": "Station C", "route": "Cargo Line", "last_updated": datetime.datetime.now().isoformat()}
    ]
    app.logger.info("Fetched mock train data.")
    return jsonify(mock_train_data)

@app.route('/api/v1/status', methods=['POST'])
def update_status():
    data = request.get_json()
    train_id = data.get('train_id')
    new_status = data.get('status')
    
    # Logic to update train status in DB (mocked for now)
    app.logger.info(f"Received status update request for {train_id} to {new_status}")
    return jsonify({"message": "Status updated", "train_id": train_id, "new_status": new_status}), 200

@app.route('/api/v1/users/<int:user_id>', methods=['GET'])
def get_user_profile(user_id):
    # Dummy user data
    if user_id == 1:
        app.logger.info(f"Accessed profile for user_id: {user_id}")
        return jsonify({"id": 1, "username": "admin", "email": "admin@traintrack.com", "role": "administrator"}), 200
    app.logger.warning(f"User with ID {user_id} not found.")
    return jsonify({"error": "User not found"}), 404

# --- Error Handlers ---
@app.errorhandler(404)
def not_found_error(error):
    app.logger.error(f"404 Not Found: {request.url}")
    return jsonify({"error": "Not Found", "message": "The requested URL was not found on the server."}), 404

@app.errorhandler(500)
def internal_error(error):
    app.logger.exception("500 Internal Server Error encountered.") # Log exception details
    return jsonify({"error": "Internal Server Error", "message": "Something went wrong on the server."}), 500

if __name__ == '__main__':
    # Setup basic logging to console/file
    import logging
    from logging.config import fileConfig
    try:
        fileConfig(AppConfig.LOGGING_CONFIG_PATH)
    except FileNotFoundError:
        logging.basicConfig(level=AppConfig.LOG_LEVEL) # Fallback if config file not found
    
    app.run(host='0.0.0.0', port=5000, debug=AppConfig.DEBUG)
